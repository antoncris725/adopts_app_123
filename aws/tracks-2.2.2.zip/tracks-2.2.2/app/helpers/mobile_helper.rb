module MobileHelper
end
