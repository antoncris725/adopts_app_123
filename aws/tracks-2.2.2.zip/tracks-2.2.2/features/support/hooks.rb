AfterStep('@pause') do
  print "Press Return to continue..."
  STDIN.getc
end
