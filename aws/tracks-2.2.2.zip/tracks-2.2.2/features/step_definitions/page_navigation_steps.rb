Then /^I should be redirected to (.+?)$/ do |page_name|
  step "I should be on #{page_name}"
end