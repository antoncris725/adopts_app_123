# config for bullet gem

if defined? Bullet
  Bullet.enable = false
  Bullet.alert = false
  Bullet.bullet_logger = true
end