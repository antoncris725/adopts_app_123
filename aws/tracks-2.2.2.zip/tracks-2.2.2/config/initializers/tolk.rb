# encoding: utf-8

# Tolk config file. Generated on July 18, 2012 13:01
# See github.com/tolk/tolk for more informations

if Rails.env==:development
  Tolk.config do |config|
  
    # If you need to add a mapping do it like this :
    # May we suggest you use http://en.wikipedia.org/wiki/List_of_ISO_639-1_codes
    # config.mapping["fr-ES"] = 'Frañol !'
  
  end
end