class Sequence
  @current_value = 0
  def self.next
    @current_value += 1
  end
end