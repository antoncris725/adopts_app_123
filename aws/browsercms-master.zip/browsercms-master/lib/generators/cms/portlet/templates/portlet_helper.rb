##
# All methods from this helper will be available in the render.html.erb for <%= class_name %>Portlet
module <%= class_name %>PortletHelper
  
end
