module Cms
  class PageRouteRequirement < Cms::PageRouteOption
    extend DefaultAccessible
  end
end