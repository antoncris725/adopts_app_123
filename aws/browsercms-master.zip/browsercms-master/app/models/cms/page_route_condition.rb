module Cms
  class PageRouteCondition < Cms::PageRouteOption
    extend DefaultAccessible
  end
end