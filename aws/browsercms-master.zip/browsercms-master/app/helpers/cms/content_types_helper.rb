module Cms
  module ContentTypesHelper
  end
end
