class TagListInput < SimpleForm::Inputs::StringInput

end