// Sets up the Cms namespace for other modules.
var Cms = Cms || {};