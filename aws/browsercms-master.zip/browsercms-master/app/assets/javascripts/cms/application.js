//
//  Javascript libraries required for the Admin area of the CMS.
//
//= require jquery
//= require jquery_ujs
//= require jquery.cookie
//= require jquery.selectbox
//= require jquery.exists
//= require jquery.taglist
//= require jquery.ui.all
//= require cms/core_library
//= require cms/content_types
//= require cms/attachment_manager
//= require cms/form_builder
//= require cms/sitemap
//= require bootstrap
//

