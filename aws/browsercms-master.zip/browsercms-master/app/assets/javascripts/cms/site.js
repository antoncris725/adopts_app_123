// The public javascript functions that must be available to guest users.
//= require 'cms/user'