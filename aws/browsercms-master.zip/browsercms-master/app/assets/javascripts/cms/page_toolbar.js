//
//  Required javascript for editing pages. Similar to toolbar.js, but adds additional features.
//
//= require jquery
//= require jquery.ui.all
//= require jquery.cookie
//= require jquery.selectbox
//= require jquery.exists
//= require jquery.taglist
//= require cms/core_library
//= require cms/attachment_manager
//= require bootstrap
//= require cms/toolbar
