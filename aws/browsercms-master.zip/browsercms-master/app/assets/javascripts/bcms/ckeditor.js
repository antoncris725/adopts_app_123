//
//  Manifest file for loading the CKeditor JS. Loads it from ckeditor-rails gem.
//  See /assets/ckeditor/config.js for default configuration.
//
//= require ckeditor-jquery
//= require bcms/ckeditor_load
//= require bcms/ckeditor_standard_config

