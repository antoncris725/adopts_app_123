module Cms
class PageRouteRequirementsController < Cms::PageRouteOptionsController
end
end