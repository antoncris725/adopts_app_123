module Cms
  class FileBlocksController < Cms::ContentBlockController
  end
end