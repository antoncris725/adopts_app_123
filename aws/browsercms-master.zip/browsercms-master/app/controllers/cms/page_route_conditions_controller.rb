module Cms
class PageRouteConditionsController < Cms::PageRouteOptionsController
end
end