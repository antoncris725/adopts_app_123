module Cms
  class HtmlBlocksController < Cms::ContentBlockController
  end
end
