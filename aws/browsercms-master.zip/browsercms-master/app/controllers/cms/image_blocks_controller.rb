module Cms
  class ImageBlocksController < Cms::ContentBlockController
  end
end