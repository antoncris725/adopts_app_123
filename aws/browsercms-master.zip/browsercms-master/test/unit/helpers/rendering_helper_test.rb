require 'test_helper'

class Cms::RenderingHelperTest < ActionView::TestCase

  def test_nothing
  end

end