require "test_helper"

describe ContentTypesHelper do

  it "must be a real test" do
    flunk "Need real tests"
  end

end
