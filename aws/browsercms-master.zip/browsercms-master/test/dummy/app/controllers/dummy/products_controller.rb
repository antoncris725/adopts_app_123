module Dummy
  class ProductsController < Cms::ContentBlockController


  end
end
