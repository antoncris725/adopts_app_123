# This exists only for testing
class Dummy::SampleBlocksController < Cms::ContentBlockController
end