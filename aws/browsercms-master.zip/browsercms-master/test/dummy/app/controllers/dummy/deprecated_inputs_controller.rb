class Dummy::DeprecatedInputsController < Cms::ContentBlockController
end
