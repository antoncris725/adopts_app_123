class Dummy::CatalogsController < Cms::ContentBlockController
end
