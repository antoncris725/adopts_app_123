# For verification that portlets are ordered alphabetically.
class AaaPortlet < Cms::Portlet

  description '[TEST] Verifies alphabetical listing of portlets.'
end