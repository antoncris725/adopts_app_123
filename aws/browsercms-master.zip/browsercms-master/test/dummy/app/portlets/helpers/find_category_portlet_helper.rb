##
# All methods from this helper will be available in the render.html.erb for FindCategoryPortlet
module FindCategoryPortletHelper
  
end
