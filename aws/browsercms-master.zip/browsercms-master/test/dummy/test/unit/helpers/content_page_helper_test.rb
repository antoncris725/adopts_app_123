require 'test_helper'

class ContentPageHelperTest < ActionView::TestCase
end
