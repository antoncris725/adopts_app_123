require 'test_helper'

class Cms::CatalogsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
