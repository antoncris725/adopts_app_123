require "test_helper"

class DesignHelperTest < ActionView::TestCase

  def test_sanity
    assert true
  end

end
