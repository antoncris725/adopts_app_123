# Used to expose behavior to the console in a single statement...
# require 'test/console_helper'
#
require 'test/test_file'
Cms.activate_logging