require 'cucumber/formatter/pretty'

module Debug
  class Formatter < Cucumber::Formatter::Pretty

  end
end