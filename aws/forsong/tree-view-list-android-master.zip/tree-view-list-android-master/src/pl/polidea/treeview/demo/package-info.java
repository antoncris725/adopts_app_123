/**
 * Provides just demo of the TreeView widget.
 */
package pl.polidea.treeview.demo;