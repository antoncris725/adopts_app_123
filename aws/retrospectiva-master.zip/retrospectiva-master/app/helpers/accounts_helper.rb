module AccountsHelper

  def html_options_for_account_form
    { :id => 'account_form' }
  end
  
end
