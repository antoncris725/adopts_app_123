class Repository::Subversion::DiffScanner < Repository::Abstract::DiffScanner
end