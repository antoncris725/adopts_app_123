#--
# Copyright (C) 2008 Dimitrij Denissenko
# Please read LICENSE document for more information.
#++
class Admin::DashboardController < AdminAreaController
  def index; end
end
