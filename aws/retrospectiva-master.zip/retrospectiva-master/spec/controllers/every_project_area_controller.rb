share_as :EveryProjectAreaController do

end unless Object.const_defined?(:EveryProjectAreaController)