require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe StoryEvent do
  fixtures :milestones, :projects, :users, :goals, :sprints, :stories, :story_events
  
end

