#--
# Copyright (C) 2009 Dimitrij Denissenko
# Please read LICENSE document for more information.
#++
module SprintsHelper
  include AgilePmHelper
end
